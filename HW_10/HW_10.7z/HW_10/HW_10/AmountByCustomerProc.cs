﻿using System;
using System.Data;
using Microsoft.SqlServer.Server;
using System.Data.SqlTypes;
using System.Data.SqlClient;

namespace HW_10
{
    // хранимая процедура с входящим параметром СustomerID, выводящую сумму покупки по этому клиенту.
    public class AmountByCustomerProc
    {
        [Microsoft.SqlServer.Server.SqlProcedure]
        public static void AmountByCustomer(int customer_id, out string customer, out decimal amount)
        {
            using (SqlConnection connection = new SqlConnection("Context Connection = true;"))
            //(@"Data Source=KORSHUNOVAA\SQL2017;Initial Catalog=WideWorldImporters;User Id=X390\user; Integrated Security=SSPI"))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(
                    "SELECT sc.CustomerName, max(sil.Quantity * sil.UnitPrice) AS amount FROM Sales.Invoices si " +
                    "JOIN Sales.InvoiceLines sil on si.InvoiceID = sil.InvoiceID " +
                    "JOIN Sales.Customers sc on si.CustomerID = sc.CustomerID " +
                    "GROUP BY si.CustomerID, sc.CustomerName " +
                    "HAVING si.CustomerID = " + customer_id, connection);
                SqlDataReader reader = command.ExecuteReader();
                SqlContext.Pipe.Send(reader);

                customer = "";
                amount = 0;
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        customer = Convert.ToString(reader[0]);
                        amount = Convert.ToDecimal(reader[1]);
                    }
                }
                reader.Close();
                connection.Close();
            }
        }
    }
}
